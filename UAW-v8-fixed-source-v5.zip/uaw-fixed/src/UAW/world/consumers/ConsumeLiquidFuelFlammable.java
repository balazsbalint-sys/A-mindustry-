package UAW.world.consumers;

import UAW.world.blocks.production.FilterGenericCrafter;
import mindustry.gen.Building;
import mindustry.graphics.Pal;
import mindustry.type.Liquid;
import mindustry.world.consumers.ConsumeLiquidFilter;

public class ConsumeLiquidFuelFlammable extends ConsumeLiquidFilter {

	public ConsumeLiquidFuelFlammable() {
		filter = liquid -> liquid.flammability > 0;
		amount = 0.1f;
	}

	@Override
	public void update(Building build) {
		super.update(build);
		if (build instanceof FilterGenericCrafter.FilterGenericCrafterBuild b) {
			Liquid liq = filter(build);
			if (liq != null) {
				b.useLiquidFuel = true;
				b.liquidEfficiency = liq.flammability;
				b.itemColor = liq.color;
			} else {
				b.itemColor = Pal.bar;
			}
		}
	}

	public Liquid filter(Building build) {
		if (build.liquids == null) return null;
		for (var liq : mindustry.Vars.content.liquids()) {
			if (filter.get(liq) && build.liquids.get(liq) > 0) return liq;
		}
		return null;
	}
}
