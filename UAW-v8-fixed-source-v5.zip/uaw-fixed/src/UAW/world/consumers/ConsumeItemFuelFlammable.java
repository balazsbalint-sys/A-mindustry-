package UAW.world.consumers;

import UAW.world.blocks.production.FilterGenericCrafter;
import mindustry.gen.Building;
import mindustry.graphics.Pal;
import mindustry.type.Item;
import mindustry.world.consumers.ConsumeItemFilter;

public class ConsumeItemFuelFlammable extends ConsumeItemFilter {

	public ConsumeItemFuelFlammable() {
		filter = item -> item.flammability > 0;
	}

	@Override
	public void update(Building build) {
		super.update(build);
		if (build instanceof FilterGenericCrafter.FilterGenericCrafterBuild b) {
			Item item = filter(build);
			if (item != null) {
				b.useItemFuel = true;
				b.itemEfficiency = item.flammability;
				b.itemColor = item.color;
			} else {
				b.itemColor = Pal.bar;
			}
		}
	}

	public Item filter(Building build) {
		var items = build.items;
		if (items == null) return null;
		for (int i = 0; i < build.items.length(); i++) {
			var item = mindustry.Vars.content.item(i);
			if (filter.get(item) && items.get(item) > 0) return item;
		}
		return null;
	}
}
